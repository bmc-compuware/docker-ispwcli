#!/bin/bash

echo "$@"